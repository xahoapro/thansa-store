# Nguồn của agent `agency-design-ui-designer`

Một agent lẻ của gói `thansa.agency-agents`, lấy từ [msitarzewski/agency-agents/design/design-ui-designer.md](https://github.com/msitarzewski/agency-agents/blob/main/design/design-ui-designer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Thansa (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Thansa báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
