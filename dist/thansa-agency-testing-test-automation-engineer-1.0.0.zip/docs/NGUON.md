# Nguồn của agent `agency-testing-test-automation-engineer`

Một agent lẻ của gói `thansa.agency-agents`, lấy từ [msitarzewski/agency-agents/testing/testing-test-automation-engineer.md](https://github.com/msitarzewski/agency-agents/blob/main/testing/testing-test-automation-engineer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Thansa (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Thansa báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
